from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import subprocess
import threading
import os
import json

app = Flask(__name__)
app.secret_key = "streamsecret"

processes = []

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == "admin" and password == "stream123":
            session["logged_in"] = True
            return redirect(url_for("dashboard"))
        else:
            return render_template("login.html", error="Username atau password salah!")
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return render_template("dashboard.html")

@app.route("/start_stream", methods=["POST"])
def start_stream():
    data = request.json
    key = data.get("key")
    video = data.get("video")
    gif = data.get("gif")
    music = data.get("music")

    rtmp_url = f"rtmp://a.rtmp.youtube.com/live2/{key}"

    if video:
        command = [
            "ffmpeg", "-re", "-stream_loop", "-1", "-i", video,
            "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
            "-c:v", "libx264", "-preset", "veryfast",
            "-c:a", "aac", "-b:a", "128k",
            "-pix_fmt", "yuv420p", "-f", "flv", rtmp_url
        ]
    else:
        command = [
            "ffmpeg", "-re",
            "-stream_loop", "-1", "-i", gif,
            "-stream_loop", "-1", "-i", music,
            "-shortest",
            "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
            "-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage",
            "-c:a", "aac", "-b:a", "128k",
            "-pix_fmt", "yuv420p", "-f", "flv", rtmp_url
        ]

    def run_stream():
        proc = subprocess.Popen(command)
        processes.append(proc)
        proc.wait()

    threading.Thread(target=run_stream, daemon=True).start()

    return jsonify({"status": "started"})

@app.route("/stop_all", methods=["POST"])
def stop_all():
    for proc in processes:
        if proc.poll() is None:
            proc.terminate()
    processes.clear()
    return jsonify({"status": "stopped"})

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)
