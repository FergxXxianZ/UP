from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
import subprocess
import threading
import os
import json
import urllib.request
import re

UPLOAD_FOLDER = "uploads"
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app = Flask(__name__)
app.secret_key = "streamsecret"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

processes = []

def download_file_from_gdrive(url, dest_path):
    # Extract file id from google drive url
    match = re.search(r'/d/([a-zA-Z0-9_-]+)', url)
    if not match:
        return False, "URL Google Drive tidak valid"
    file_id = match.group(1)
    download_url = f"https://drive.google.com/uc?export=download&id={file_id}"
    try:
        urllib.request.urlretrieve(download_url, dest_path)
        return True, None
    except Exception as e:
        return False, str(e)

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == "admin" and password == "stream123":
            session["logged_in"] = True
            return redirect(url_for("dashboard"))
        else:
            return render_template("login.html", error="Username atau password salah!")
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return render_template("dashboard.html")

@app.route("/upload", methods=["POST"])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "Tidak ada file yang diupload"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "Nama file kosong"}), 400
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)
    return jsonify({"message": "File berhasil diupload", "filepath": filepath})

@app.route("/start_stream", methods=["POST"])
def start_stream():
    data = request.json
    key = data.get("key")
    video = data.get("video")
    gif = data.get("gif")
    music = data.get("music")

    def prepare_file(path_or_url, default_name):
        if path_or_url and path_or_url.startswith("http"):
            filename = default_name
            dest_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            success, error = download_file_from_gdrive(path_or_url, dest_path)
            if not success:
                raise Exception(f"Download gagal: {error}")
            return dest_path
        else:
            return path_or_url

    try:
        video_path = prepare_file(video, "video.mp4") if video else None
        gif_path = prepare_file(gif, "gif.gif") if gif else None
        music_path = prepare_file(music, "music.mp3") if music else None
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

    rtmp_url = f"rtmp://a.rtmp.youtube.com/live2/{key}"

    if video_path:
        command = [
            "ffmpeg", "-re", "-stream_loop", "-1", "-i", video_path,
            "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
            "-c:v", "libx264", "-preset", "veryfast",
            "-c:a", "aac", "-b:a", "128k",
            "-pix_fmt", "yuv420p", "-f", "flv", rtmp_url
        ]
    else:
        if not (gif_path and music_path):
            return jsonify({"status": "error", "message": "GIF dan Musik harus disediakan jika video tidak ada"}), 400
        command = [
            "ffmpeg", "-re",
            "-stream_loop", "-1", "-i", gif_path,
            "-stream_loop", "-1", "-i", music_path,
            "-shortest",
            "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
            "-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage",
            "-c:a", "aac", "-b:a", "128k",
            "-pix_fmt", "yuv420p", "-f", "flv", rtmp_url
        ]

    def run_stream():
        proc = subprocess.Popen(command)
        processes.append(proc)
        proc.wait()

    threading.Thread(target=run_stream, daemon=True).start()

    return jsonify({"status": "started"})

@app.route("/stop_all", methods=["POST"])
def stop_all():
    for proc in processes:
        if proc.poll() is None:
            proc.terminate()
    processes.clear()
    return jsonify({"status": "stopped"})

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)
