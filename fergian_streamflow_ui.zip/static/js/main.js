async function uploadFile(file){
  if(!file)return null;
  const formData=new FormData();formData.append('file',file);
  const res=await fetch('/upload',{method:'POST',body:formData});
  const data=await res.json();
  if(res.ok)return data.filepath;
  alert(data.error);return null;
}
async function uploadAndStart(){
  const key=document.getElementById('key').value.trim();
  const videoFile=document.getElementById('video_file').files[0];
  const gifFile=document.getElementById('gif_file').files[0];
  const musicFile=document.getElementById('music_file').files[0];
  const videoUrl=document.getElementById('video_url').value.trim();
  const gifUrl=document.getElementById('gif_url').value.trim();
  const musicUrl=document.getElementById('music_url').value.trim();
  if(!key)return alert('Stream key wajib diisi.');
  document.getElementById('log').value+='⏳ Uploading files...\n';
  const videoPath=videoUrl||await uploadFile(videoFile);
  const gifPath=gifUrl||await uploadFile(gifFile);
  const musicPath=musicUrl||await uploadFile(musicFile);
  const res=await fetch('/start_stream',{method:'POST',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({key,video:videoPath,gif:gifPath,music:musicPath})});
  const data=await res.json();
  document.getElementById('log').value+=JSON.stringify(data)+'\n';
}
async function stopAll(){
  const res=await fetch('/stop_all',{method:'POST'});
  const data=await res.json();
  document.getElementById('log').value+=JSON.stringify(data)+'\n';
}
